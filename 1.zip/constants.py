configYamlPath = "./configs/"  # Change it according to the directory of the platform on which the code is being run
datasetDir = "./data/"
saveLocation = "./plots/"